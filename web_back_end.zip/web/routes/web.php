<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/pessoas', 'PessoaController@lista');

Route::post('/pessoas', 'PessoaController@novo');

Route::put('/pessoa/{id}', 'PessoaController@editar');

Route::delete('/pessoa/{id}', 'PessoaController@excluir');


///////////////////////////////////////////////////////
//// Tipo de Usuário

Route::get('/tuser', 'Tuser@lista');


///////////////////////////////////////////////////////
//// Usuário

Route::get('/usuarios', 'User@lista');

Route::post('/usuarios', 'User@novo');

Route::put('/usuarios/{id}', 'User@editar');


///////////////////////////////////////////////////////
//// Login

Route::post('/login', 'Login@entrar');


///////////////////////////////////////////////////////
//// Curso

Route::get('/cursos', 'Curso@lista');

Route::post('/cursos', 'Curso@novo');

Route::put('/cursos/{id}', 'Curso@editar');



///////////////////////////////////////////////////////
//// Disciplina

Route::get('/disciplinas', 'Disciplina@lista');

Route::post('/disciplinas', 'Disciplina@novo');

Route::put('/disciplinas/{id}', 'Disciplina@editar');



///////////////////////////////////////////////////////
//// Turma

Route::get('/turmas', 'Turma@lista');

Route::post('/turmas', 'Turma@novo');

Route::put('/turmas/{id}', 'Turma@editar');

