<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB; // para usar a classe DB

class Curso extends Controller
{
	
	public function lista(){
		return DB::select('select * from curso');
	}
	
	// Cadastrando Curso
	public function novo(Request $request){
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
 
		$res = DB::insert('insert into curso (curso) values (?)', [$data['curso']]); // Insert
		return ["status" => ($res)?'ok':'erro'];
		
	}
	
	// Editando Curso
	public function editar($id, Request $request){
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
		
		$res = DB::update("update curso set curso = ? WHERE id = ?",[$data['curso'], $id]); //Update
 
		return ["status" => ($res)?'ok':'erro'];
	}
	
}
