<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB; // para usar a classe DB

class Turma extends Controller
{
   
	public function lista(){
		return DB::select('select * from turma');
	}

	// Cadastrando Turma
	public function novo(Request $request){
		
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
		$res = DB::insert('insert into turma (codigo_turma, dia_semana, professor_id, curso_id) values (?, ?, ?, ?)', [$data['codigo_turma'], $data['dia_semana'], $data['professor_id'], $data['curso_id']]); // Insert
		return ["status" => ($res)?'ok':'erro'];
		
	}

	// Editando Turma
	public function editar($id, Request $request){
		
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
		$res = DB::update("update turma set codigo_turma = ?, dia_semana = ?, professor_id = ?, curso_id = ? WHERE id = ?",[$data['codigo_turma'], $data['dia_semana'], $data['professor_id'], $data['curso_id'], $id]); //Update
		return ["status" => ($res)?'ok':'erro'];
		
	}
}
