<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB; // para usar a classe DB

class Disciplina extends Controller
{
    
	public function lista(){
		return DB::select('select * from disciplina');
	}

	// Cadastrando Disciplina
	public function novo(Request $request){
		
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
		$res = DB::insert('insert into disciplina (curso_id, disciplina) values (?, ?)', [$data['curso_id'], $data['disciplina']]); // Insert
		return ["status" => ($res)?'ok':'erro'];
		
	}

	// Editando Disciplina
	public function editar($id, Request $request){
		
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
		$res = DB::update("update disciplina set curso_id = ?, disciplina = ? WHERE id = ?",[$data['curso_id'], $data['disciplina'], $id]); //Update
		return ["status" => ($res)?'ok':'erro'];
		
	}
	
}
