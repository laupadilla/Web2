<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB; // para usar a classe DB

class User extends Controller
{
	
	public function lista(){
		return DB::select('select id, nome, tipo_user_id, usuario, status from usuario');
	}
	
	// Cadastrando Usuários
	public function novo(Request $request){
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
 
		$res = DB::insert('insert into usuario (nome, tipo_user_id, usuario, senha, email, status) values (?, ?, ?, ?, ?, "A")', [$data['nome'], $data['tipo_user_id'], $data['usuario'], md5($data['senha']), $data['email']]); // Insert
		return ["status" => ($res)?'ok':'erro'];
		
	}

	// Editando Usuários
	public function editar($id, Request $request){
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
		
		$res = DB::update("update usuario set nome = ?, tipo_user_id = ?, usuario = ?, email = ?, status = ? WHERE id = ?",[$data['nome'], $data['tipo_user_id'], $data['usuario'], $data['email'], $data['status'], $id]); //Update
 
		return ["status" => ($res)?'ok':'erro'];
	}
	
	
}
