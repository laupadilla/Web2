<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB; // para usar a classe DB

class Login extends Controller
{
    
	public function entrar(Request $request){
		
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
		
		$usuario 	= $data['usuario'];
		$senha 		= md5($data['senha']);
		
		return DB::select("select count(*) as resultado from usuario WHERE usuario = '$usuario' and senha = '$senha'");
		
	}
	
}
