<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB; // para usar a classe DB

class Tuser extends Controller
{
    public function lista(){
		return DB::select('select * from tipo_usuario');
	}
}
